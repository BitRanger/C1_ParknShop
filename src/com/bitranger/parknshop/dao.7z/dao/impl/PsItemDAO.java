package com.bitranger.parknshop.dao.impl;


import java.sql.SQLException;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.LockMode;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.bitranger.parknshop.dao.FetchOption;
import com.bitranger.parknshop.dao.IPsItemDAO;
import com.bitranger.parknshop.dao.SortOption;
import com.bitranger.parknshop.model.PsComment;
import com.bitranger.parknshop.model.PsItem;
import com.bitranger.parknshop.model.PsOrder;

/**
 * A data access object (DAO) providing persistence and search support for
 * PsItem entities. Transaction control of the save(), update() and delete()
 * operations can directly support Spring container-managed transactions or they
 * can be augmented to handle user-managed Spring transactions. Each of these
 * methods provides additional information for how to configure it for the
 * desired type of transaction control.
 * 
 * @see com.bitranger.PsItem
 * @author MyEclipse Persistence Tools
 */
public class PsItemDAO extends HibernateDaoSupport implements IPsItemDAO{
	private static final Logger log = LoggerFactory.getLogger(PsItemDAO.class);
	// property constants
	public static final String NAME = "name";
	public static final String INTRODUCTION = "introduction";
	public static final String PRICE = "price";
	public static final String URL_PICTURE = "urlPicture";
	public static final String EXTRA1 = "extra1";
	public static final String EXTRA2 = "extra2";
	public static final String COUNT_PURCHASE = "countPurchase";
	public static final String COUNT_FAVOURITE = "countFavourite";
	public static final String COUNT_CLICK = "countClick";
	public static final String VOTE = "vote";

	@Override
	public void save(PsItem transientInstance) {
		log.debug("saving PsItem instance");
		try {
			getHibernateTemplate().save(transientInstance);
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
	}

	@Override
	public void delete(PsItem persistentInstance) {
		log.debug("deleting PsItem instance");
		try {
			getHibernateTemplate().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	@Override
	public PsItem findById(java.lang.Integer id) {
		log.debug("getting PsItem instance with id: " + id);
		try {
			PsItem instance = (PsItem) getHibernateTemplate().get(
					"com.bitranger.PsItem", id);
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	public List<PsItem> findByExample(PsItem instance) {
		log.debug("finding PsItem instance by example");
		try {
			@SuppressWarnings("unchecked")
			List<PsItem> results = (List<PsItem>) getHibernateTemplate()
					.findByExample(instance);
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}

	@SuppressWarnings("unchecked")
	public List<PsItem> findByProperty(String propertyName, Object value) {
		log.debug("finding PsItem instance with property: " + propertyName
				+ ", value: " + value);
		try {
			String queryString = "from PsItem as model where model."
					+ propertyName + "= ?";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			log.error("find by property name failed", re);
			throw re;
		}
	}


	@SuppressWarnings("unchecked")
	public List<PsItem> findAll() {
		log.debug("finding all PsItem instances");
		try {
			String queryString = "from PsItem";
			return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}

	//�������е�update����void����ķ���ֵ�Ǹ�ʵ�壬�ǲ��Ǵ��ˣ������Ҹĳ���void
	@Override
	public void update(PsItem detachedInstance) {
		getHibernateTemplate().update(detachedInstance);
	}

	//��νkeyword��ʲô��������Ľӿ���û��һ��ע�ͣ������֪��Ҫ���ʲô����
	@Override
	public List<PsItem> searchByKeyword(String keyword) {
		// TODO Auto-generated method stub
		return null;
	}

	
	//fetchoption��أ�����һ��û��get��������֪������������ã��ӿڸ�ĺ�����û��ע�ͣ���ֻ�ܸ�ݲ���²��ˡ�����
	@SuppressWarnings("unchecked")
	//�������fetchoption����Ķ�û��д��������������绰˵�ˡ�����
	@Override
	public List<PsItem> findByPriceInCategory(final Integer psCategoryId,
			final Double priceMin, final Double priceMax, final FetchOption option) {
		try {
			return getHibernateTemplate().executeFind(new HibernateCallback<List<PsItem>>() {
				@Override
				public List<PsItem> doInHibernate(Session session)
						throws HibernateException, SQLException {
					SQLQuery query = session.createSQLQuery(
					"select * from ps_item as P where P.id_category = ? "
					+ " and P.price > ? and P.price < ? "
					+ "order by price " + (option.sortOption == SortOption.ASCENDING 
									? "asc" : "desc")
					+ " offset ? limit ?");
					
					query.setInteger(0, psCategoryId)
						.setDouble(1, priceMin)
						.setDouble(2, priceMax)
						.setInteger(3, option.offset)
						.setInteger(4, option.limit);
						
					return query.addEntity(PsItem.class).list();
				}
			});
		} catch (RuntimeException re) {
			log.error("find by findByPriceInCategory failed", re);
			throw re;
		}
	}

	@Override
	public List<PsItem> findByCountPurchaseInCategory(Integer psCategoryId,
			FetchOption op) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<PsItem> findByCountFavouriteInCategory(Integer psCategoryId,
			FetchOption op) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<PsItem> findByVoteInCategory(Integer psCategoryId,
			FetchOption op) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<PsItem> findByPriceInTag(Integer psTagId, Double priceMin,
			Double priceMax, FetchOption op) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<PsItem> findByCountPurchaseInTag(Integer psTagId, FetchOption op) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<PsItem> findByCountFavouriteInTag(Integer psTagId,
			FetchOption op) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<PsItem> findByVoteInTag(Integer psTagId, FetchOption op) {
		// TODO Auto-generated method stub
		return null;
	}

	@SuppressWarnings("null")
	@Override
	public List<PsItem> findByOrderId(Integer id) {
		PsOrderDAO orderDAO = new PsOrderDAO();
		PsOrder order = orderDAO.findByOrderId(id);
		List<PsItem> items = this.findAll();
		List<PsItem> retList = null;
		for (int i=0;i<items.size();i++){
			if (items.get(i).getId() == order.getId()){
				retList.add(items.get(i));
			}
		}
		return retList;
	}

	@Override
	public List<PsItem> findBySeller(Integer sellerId, FetchOption fetchOption) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<PsItem> findByShop(Integer shopId, FetchOption fetchOption) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<PsItem> findByCountPurchase(FetchOption op) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<PsItem> findByCountFavourite(FetchOption op) {
		// TODO Auto-generated method stub
		return null;
	}

}