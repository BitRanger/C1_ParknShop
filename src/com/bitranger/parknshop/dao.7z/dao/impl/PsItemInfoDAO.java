package com.bitranger.parknshop.dao.impl;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.bitranger.parknshop.dao.IPsItemInfoDAO;
import com.bitranger.parknshop.model.PsItemInfo;

/**
 * A data access object (DAO) providing persistence and search support for
 * PsItemInfo entities. Transaction control of the save(), update() and delete()
 * operations can directly support Spring container-managed transactions or they
 * can be augmented to handle user-managed Spring transactions. Each of these
 * methods provides additional information for how to configure it for the
 * desired type of transaction control.
 * 
 * @see com.bitranger.PsItemInfo
 * @author MyEclipse Persistence Tools
 */
public class PsItemInfoDAO extends HibernateDaoSupport implements IPsItemInfoDAO{
	private static final Logger log = LoggerFactory
			.getLogger(PsItemInfoDAO.class);
	public  void update(PsItemInfo detachedInstance)
	{
		log.debug("updating PsItem instance");
		try {
			getHibernateTemplate().update(detachedInstance);
			log.debug("update successful");
		} catch (RuntimeException re) {
			log.error("update failed", re);
			throw re;
		}
	}
	
	public  void save(PsItemInfo transientInstance)
	{
		log.debug("saving PsItemInfo instance");
		try {
			getHibernateTemplate().save(transientInstance);
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
	}
	
	public  void delete(PsItemInfo persistentInstance)
	{
		log.debug("deleting PsItemInfo instance");
		try {
			getHibernateTemplate().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}
	@SuppressWarnings("null")
	public  List<PsItemInfo> findByItemId(java.lang.Integer id)
	{
		List<PsItemInfo> retList = null;
		List<PsItemInfo> ItemList = this.findAll();
		for (int i=0;i<ItemList.size();i++){
			if (ItemList.get(i).getIdItem() == id){
				retList.add(ItemList.get(i));
			}
		}

		return retList;
	}
	@SuppressWarnings("unchecked")
	private List<PsItemInfo> findAll() {
		log.debug("finding all PsOrder instances");
		try {
			String queryString = "from PsOrder";
			return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}
}