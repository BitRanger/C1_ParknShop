package com.bitranger.parknshop.dao.impl;

import java.util.List;
import org.hibernate.LockMode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.bitranger.parknshop.dao.IPsRecipientDAO;
import com.bitranger.parknshop.model.PsRecipient;

/**
 * A data access object (DAO) providing persistence and search support for
 * PsRecipient entities. Transaction control of the save(), update() and
 * delete() operations can directly support Spring container-managed
 * transactions or they can be augmented to handle user-managed Spring
 * transactions. Each of these methods provides additional information for how
 * to configure it for the desired type of transaction control.
 * 
 * @see com.bitranger.PsRecipient
 * @author MyEclipse Persistence Tools
 */
public class PsRecipientDAO extends HibernateDaoSupport implements IPsRecipientDAO{
	private static final Logger log = LoggerFactory
			.getLogger(PsRecipientDAO.class);
	// property constants
	public static final String NAME_RECIPIENT = "nameRecipient";
	public static final String ADDRESSS = "addresss";
	public static final String POSTAL_CODE = "postalCode";
	public static final String PHONE_NUMBER = "phoneNumber";

	protected void initDao() {
		// do nothing
	}

	public void save(PsRecipient transientInstance) {
		log.debug("saving PsRecipient instance");
		try {
			getHibernateTemplate().save(transientInstance);
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
	}

	public void delete(PsRecipient persistentInstance) {
		log.debug("deleting PsRecipient instance");
		try {
			getHibernateTemplate().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	private PsRecipient findById(java.lang.Integer id) {
		log.debug("getting PsRecipient instance with id: " + id);
		try {
			PsRecipient instance = (PsRecipient) getHibernateTemplate().get(
					"com.bitranger.PsRecipient", id);
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	private List findAll() {
		log.debug("finding all PsRecipient instances");
		try {
			String queryString = "from PsRecipient";
			return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}


	@Override
	public void update(PsRecipient detachedInstance) {
		getHibernateTemplate().update(detachedInstance);
	}

	@Override
	public PsRecipient findByRecipientId(Integer id) {
		return findById(id);
	}

	@Override
	public List<PsRecipient> findByCustomId(Integer id) {
		List<PsRecipient> reciList = this.findAll();
		List<PsRecipient> retList = null;
		for (int i=0;i<reciList.size();i++){
			if (reciList.get(i).getPsCustomer().getId()==id){
				retList.add(reciList.get(i));
			}
		}
		return retList;
	}
}