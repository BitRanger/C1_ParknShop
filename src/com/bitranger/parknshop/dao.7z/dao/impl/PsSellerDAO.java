package com.bitranger.parknshop.dao.impl;

import java.sql.Timestamp;
import java.util.List;
import java.util.Set;
import org.hibernate.LockMode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.bitranger.parknshop.dao.FetchOption;
import com.bitranger.parknshop.dao.IPsSellerDAO;
import com.bitranger.parknshop.model.PsCustomer;
import com.bitranger.parknshop.model.PsSeller;

/**
 * A data access object (DAO) providing persistence and search support for
 * PsSeller entities. Transaction control of the save(), update() and delete()
 * operations can directly support Spring container-managed transactions or they
 * can be augmented to handle user-managed Spring transactions. Each of these
 * methods provides additional information for how to configure it for the
 * desired type of transaction control.
 * 
 * @see com.bitranger.PsSeller
 * @author MyEclipse Persistence Tools
 */
public class PsSellerDAO extends HibernateDaoSupport implements IPsSellerDAO{
	private static final Logger log = LoggerFactory
			.getLogger(PsSellerDAO.class);
	// property constants
	public static final String NICKNAME = "nickname";
	public static final String PERSON_ID_NUM = "personIdNum";
	public static final String EMAIL = "email";
	public static final String PASSWORD = "password";
	public static final String STATUS = "status";

	protected void initDao() {
		// do nothing
	}

	public void save(PsSeller transientInstance) {
		log.debug("saving PsSeller instance");
		try {
			getHibernateTemplate().save(transientInstance);
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
	}

	public void delete(PsSeller persistentInstance) {
		log.debug("deleting PsSeller instance");
		try {
			getHibernateTemplate().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	private List findByProperty(String propertyName, Object value) {
		log.debug("finding PsSeller instance with property: " + propertyName
				+ ", value: " + value);
		try {
			String queryString = "from PsSeller as model where model."
					+ propertyName + "= ?";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			log.error("find by property name failed", re);
			throw re;
		}
	}


	private List findAll() {
		log.debug("finding all PsSeller instances");
		try {
			String queryString = "from PsSeller";
			return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}

	@Override
	public void update(PsSeller detachedInstance) {
		getHibernateTemplate().update(detachedInstance);
	}

	@Override
	public PsSeller findByEmail(String email) {
		List<PsSeller> sellerList = this.findAll();
		PsSeller retSeller = null;
		for (int i=0;i<sellerList.size();i++){
			if (sellerList.get(i).getEmail().equals(email)){
				retSeller = sellerList.get(i);
			}
		}
		return retSeller;
	}

	@Override
	public List<PsCustomer> findAll(FetchOption fetchOption) {
		
		return null;
	}
}