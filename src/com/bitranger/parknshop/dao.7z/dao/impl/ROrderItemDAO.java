package com.bitranger.parknshop.dao.impl;

import java.util.List;
import org.hibernate.LockMode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.bitranger.parknshop.dao.IPsOrderDAO;
import com.bitranger.parknshop.dao.IPsRecipientDAO;
import com.bitranger.parknshop.dao.IROrderItemDAO;
import com.bitranger.parknshop.model.ROrderItem;

/**
 * A data access object (DAO) providing persistence and search support for
 * ROrderItem entities. Transaction control of the save(), update() and delete()
 * operations can directly support Spring container-managed transactions or they
 * can be augmented to handle user-managed Spring transactions. Each of these
 * methods provides additional information for how to configure it for the
 * desired type of transaction control.
 * 
 * @see com.bitranger.ROrderItem
 * @author MyEclipse Persistence Tools
 */
public class ROrderItemDAO extends HibernateDaoSupport implements IROrderItemDAO{
	private static final Logger log = LoggerFactory
			.getLogger(ROrderItemDAO.class);
	// property constants
	public static final String QUANTITIY = "quantitiy";
	public static final String EXTRA1 = "extra1";
	public static final String EXTRA2 = "extra2";

	protected void initDao() {
		// do nothing
	}

	public void save(ROrderItem transientInstance) {
		log.debug("saving ROrderItem instance");
		try {
			getHibernateTemplate().save(transientInstance);
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
	}

	public void delete(ROrderItem persistentInstance) {
		log.debug("deleting ROrderItem instance");
		try {
			getHibernateTemplate().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	public ROrderItem findById(com.bitranger.parknshop.model.ROrderItemId id) {
		log.debug("getting ROrderItem instance with id: " + id);
		try {
			ROrderItem instance = (ROrderItem) getHibernateTemplate().get(
					"com.bitranger.ROrderItem", id);
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	public List<ROrderItem> findByExample(ROrderItem instance) {
		log.debug("finding ROrderItem instance by example");
		try {
			List<ROrderItem> results = (List<ROrderItem>) getHibernateTemplate()
					.findByExample(instance);
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}

	public List findByProperty(String propertyName, Object value) {
		log.debug("finding ROrderItem instance with property: " + propertyName
				+ ", value: " + value);
		try {
			String queryString = "from ROrderItem as model where model."
					+ propertyName + "= ?";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			log.error("find by property name failed", re);
			throw re;
		}
	}

	public List<ROrderItem> findByQuantitiy(Object quantitiy) {
		return findByProperty(QUANTITIY, quantitiy);
	}

	public List<ROrderItem> findByExtra1(Object extra1) {
		return findByProperty(EXTRA1, extra1);
	}

	public List<ROrderItem> findByExtra2(Object extra2) {
		return findByProperty(EXTRA2, extra2);
	}

	public List findAll() {
		log.debug("finding all ROrderItem instances");
		try {
			String queryString = "from ROrderItem";
			return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}

	public ROrderItem merge(ROrderItem detachedInstance) {
		log.debug("merging ROrderItem instance");
		try {
			ROrderItem result = (ROrderItem) getHibernateTemplate().merge(
					detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public void attachDirty(ROrderItem instance) {
		log.debug("attaching dirty ROrderItem instance");
		try {
			getHibernateTemplate().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(ROrderItem instance) {
		log.debug("attaching clean ROrderItem instance");
		try {
			getHibernateTemplate().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public static ROrderItemDAO getFromApplicationContext(ApplicationContext ctx) {
		return (ROrderItemDAO) ctx.getBean("ROrderItemDAO");
	}

	@Override
	public void update(ROrderItem detachedInstance) {
		getHibernateTemplate().update(detachedInstance);
	}

	@Override
	public List<ROrderItem> findByOrderId(Integer id) {
		List<ROrderItem> retList = null;
		List<ROrderItem> oiList = this.findAll();
		for (int i=0;i<oiList.size();i++){
			if (oiList.get(i).getPsOrder().getId() == id){
				retList.add(oiList.get(i));
			}
		}
		return retList;
	}
}