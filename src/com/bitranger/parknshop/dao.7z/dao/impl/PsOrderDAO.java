package com.bitranger.parknshop.dao.impl;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Set;
import org.hibernate.LockMode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.bitranger.parknshop.core.OrderState;
import com.bitranger.parknshop.dao.IPsOrderDAO;
import com.bitranger.parknshop.model.PsOrder;

/**
 * A data access object (DAO) providing persistence and search support for
 * PsOrder entities. Transaction control of the save(), update() and delete()
 * operations can directly support Spring container-managed transactions or they
 * can be augmented to handle user-managed Spring transactions. Each of these
 * methods provides additional information for how to configure it for the
 * desired type of transaction control.
 * 
 * @see com.bitranger.PsOrder
 * @author MyEclipse Persistence Tools
 */
public class PsOrderDAO extends HibernateDaoSupport implements IPsOrderDAO{
	private static final Logger log = LoggerFactory.getLogger(PsOrderDAO.class);
	public  void save(PsOrder transientInstance)
	{
		log.debug("saving PsOrder instance");
		try {
			getHibernateTemplate().save(transientInstance);
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
	}
	public  void delete(PsOrder persistentInstance)
	{
		log.debug("deleting PsOrder instance");
		try {
			getHibernateTemplate().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}
	public  void update(PsOrder detachedInstance)
	{
		log.debug("updating PsItem instance");
		try {
			getHibernateTemplate().update(detachedInstance);
			log.debug("update successful");
		} catch (RuntimeException re) {
			log.error("update failed", re);
			throw re;
		}
	}
	
	public  PsOrder findByOrderId(Integer id)
	{
		log.debug("getting PsOrder instance with id: " + id);
		try {
			PsOrder instance = (PsOrder) getHibernateTemplate().get(
					"com.bitranger.PsOrder", id);
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
	
	public  List<PsOrder> findByCustomerId(Integer id, Date from, Date to)
	{
		List<PsOrder> retList = null;
		List<PsOrder> orderList = this.findAll(from,to);
		for (int i=0;i<orderList.size();i++){
//			�ҵĹ�����û��date����ࡣ����������ж�û��д��
		}

		return retList;
	}
	public  List<PsOrder> findByCustomerId(Integer id, OrderState state)
	{
		List<PsOrder> retList = null;
		List<PsOrder> orderList = this.findAll(state);
		for (int i=0;i<orderList.size();i++){
			if (orderList.get(i).getIdShop() == id){
				retList.add(orderList.get(i));
			}
		}

		return retList;
	}
	public  List<PsOrder> findByShopId(Integer id, Date from, Date to)
	{
		List<PsOrder> retList = null;
		List<PsOrder> orderList = this.findAll(from,to);
		for (int i=0;i<orderList.size();i++){
//			�ҵĹ�����û��date����ࡣ����������ж�û��д��
		}

		return retList;
	}
	public  List<PsOrder> findByShopId(Integer id, OrderState state)
	{
		List<PsOrder> retList = null;
		List<PsOrder> orderList = this.findAll(state);
		for (int i=0;i<orderList.size();i++){
			if (orderList.get(i).getIdShop() == id){
				retList.add(orderList.get(i));
			}
		}

		return retList;
	}
	public  List<PsOrder> findAll(OrderState state)
	{
		List<PsOrder> retList = null;
		List<PsOrder> orderlist = this.findAll();
		for (int i=0;i<orderlist.size();i++){
			if (orderlist.get(i).getStatus().equals(state)){
				retList.add(orderlist.get(i));
			}
		}
		return retList;
	}
	public  List<PsOrder> findAll(Date from, Date to)
	{
		List<PsOrder> retList = null;
		List<PsOrder> orderlist = this.findAll();
		for (int i=0;i<orderlist.size();i++){
			if (orderlist.get(i).getTimeCreated().before(to) && orderlist.get(i).getTimeCreated().after(from)){
				retList.add(orderlist.get(i));
			}
		}
		return retList;
	}

	private List findAll() {
		log.debug("finding all PsOrder instances");
		try {
			String queryString = "from PsOrder";
			return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}
	private List findByProperty(String propertyName, Object value) {
		log.debug("finding PsOrder instance with property: " + propertyName
				+ ", value: " + value);
		try {
			String queryString = "from PsOrder as model where model."
					+ propertyName + "= ?";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			log.error("find by property name failed", re);
			throw re;
		}
	}
}